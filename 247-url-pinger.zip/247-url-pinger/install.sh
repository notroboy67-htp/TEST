#!/usr/bin/env bash
set -e
echo "Installing 24/7 URL Pinger..."
if command -v apt >/dev/null; then sudo apt update && sudo apt install -y python3 python3-venv python3-pip curl; fi
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
mkdir -p data
echo "Installed. Run: ./start.sh"

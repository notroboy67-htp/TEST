# 24/7 URL Pinger

A mobile-friendly Flask dashboard with a server-side APScheduler worker and SQLite persistence.

## Ubuntu / Termux

```bash
chmod +x install.sh start.sh stop.sh restart.sh
./install.sh
./start.sh
```

Open `http://127.0.0.1:3000`.

For another port:
```bash
PORT=8080 ./start.sh
```

## What is included

- HTTP/HTTPS URL validation
- 5/7/10/30/60 second intervals (custom values >=5 are accepted by API)
- Server-side scheduler, not browser `setInterval`
- SQLite persistence and automatic restoration of running tasks after restart
- Per-task success/failure statistics and logs
- DNS, timeout and HTTP error handling
- Per-task isolation
- SSRF checks against localhost, private/link-local/reserved/multicast/metadata-style hosts
- Maximum task limit
- Responsive dark/light UI

## Production

For a real public deployment, put the app behind a reverse proxy such as Nginx/Caddy and use a production WSGI server. For simple testing, `python3 app.py` is enough.

### systemd (Ubuntu)

Create `/etc/systemd/system/url-pinger.service`:

```ini
[Unit]
Description=24/7 URL Pinger
After=network.target

[Service]
WorkingDirectory=/opt/247-url-pinger
ExecStart=/opt/247-url-pinger/venv/bin/gunicorn -w 2 -b 127.0.0.1:3000 app:app
Restart=always

[Install]
WantedBy=multi-user.target
```

Install Gunicorn:
```bash
source venv/bin/activate
pip install gunicorn
sudo systemctl daemon-reload
sudo systemctl enable --now url-pinger
```

## Security note

This is designed for trusted/small deployments. Before exposing it publicly, add authentication, per-user ownership, persistent rate limiting, and a hardened egress/SSRF policy. Redirects are disabled intentionally so a safe initial hostname cannot bounce the worker into a private destination.

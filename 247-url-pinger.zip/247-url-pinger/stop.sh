#!/usr/bin/env bash
if [ -f pinger.pid ]; then kill "$(cat pinger.pid)" 2>/dev/null || true; rm -f pinger.pid; echo "Stopped."; else echo "Not running."; fi

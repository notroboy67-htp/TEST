#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
[ -d venv ] || { echo "Run ./install.sh first"; exit 1; }
source venv/bin/activate
export PORT="${PORT:-3000}"
nohup python3 app.py > pinger.log 2>&1 &
echo $! > pinger.pid
echo "24/7 URL Pinger running on port $PORT (PID $(cat pinger.pid))"

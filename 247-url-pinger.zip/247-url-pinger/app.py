import os, ipaddress, socket, threading, time, uuid
from datetime import datetime, timezone
from urllib.parse import urlparse

import requests
from apscheduler.schedulers.background import BackgroundScheduler
from flask import Flask, jsonify, render_template, request

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, "data", "pinger.db")
PORT = int(os.getenv("PORT", "3000"))
MAX_TASKS = int(os.getenv("MAX_TASKS", "10"))
TIMEOUT = float(os.getenv("REQUEST_TIMEOUT", "12"))

app = Flask(__name__)
scheduler = BackgroundScheduler(daemon=True)
lock = threading.RLock()

import sqlite3
def db():
    c = sqlite3.connect(DB, check_same_thread=False)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    os.makedirs(os.path.dirname(DB), exist_ok=True)
    c = db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS tasks (
      id TEXT PRIMARY KEY, url TEXT NOT NULL, interval INTEGER NOT NULL,
      running INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL,
      started_at TEXT, success INTEGER NOT NULL DEFAULT 0,
      failed INTEGER NOT NULL DEFAULT 0, last_request TEXT,
      next_request TEXT, status TEXT NOT NULL DEFAULT 'Stopped',
      last_code INTEGER, last_error TEXT
    );
    CREATE TABLE IF NOT EXISTS logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT, task_id TEXT NOT NULL,
      timestamp TEXT NOT NULL, code INTEGER, success INTEGER NOT NULL,
      response_ms INTEGER, error TEXT
    );
    """)
    c.commit(); c.close()

def valid_public_url(raw):
    try:
        p = urlparse(raw.strip())
        if p.scheme not in ("http", "https") or not p.hostname:
            return False, "Only valid HTTP/HTTPS URLs are allowed."
        host = p.hostname
        if host.lower() in {"localhost", "metadata.google.internal"}:
            return False, "Local or cloud metadata hosts are blocked."
        try:
            infos = socket.getaddrinfo(host, p.port or (443 if p.scheme=="https" else 80), type=socket.SOCK_STREAM)
            for info in infos:
                ip = ipaddress.ip_address(info[4][0])
                if (ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast
                    or ip.is_reserved or ip.is_unspecified):
                    return False, "Private, loopback, link-local, multicast, reserved, or unspecified IPs are blocked."
        except socket.gaierror:
            return False, "DNS lookup failed."
        return True, ""
    except Exception:
        return False, "Invalid URL."

def log_request(task_id, code, success, ms, error=None):
    now = datetime.now(timezone.utc).isoformat()
    c = db()
    c.execute("INSERT INTO logs(task_id,timestamp,code,success,response_ms,error) VALUES(?,?,?,?,?,?)",
              (task_id, now, code, int(success), ms, error))
    c.execute("DELETE FROM logs WHERE task_id=? AND id NOT IN (SELECT id FROM logs WHERE task_id=? ORDER BY id DESC LIMIT 200)",
              (task_id, task_id))
    c.commit(); c.close()

def ping_task(task_id):
    c = db(); row = c.execute("SELECT * FROM tasks WHERE id=?", (task_id,)).fetchone(); c.close()
    if not row or not row["running"]: return
    started = time.monotonic()
    code, ok, err = None, False, None
    try:
        good, msg = valid_public_url(row["url"])
        if not good: raise RuntimeError(msg)
        r = requests.get(row["url"], timeout=TIMEOUT, allow_redirects=False,
                         headers={"User-Agent":"247-URL-Pinger/1.0"}, stream=True)
        code = r.status_code
        r.close()
        ok = 200 <= code < 400
        if not ok: err = f"HTTP {code}"
    except Exception as e:
        err = str(e)[:500]
    ms = int((time.monotonic()-started)*1000)
    now = datetime.now(timezone.utc).isoformat()
    next_t = datetime.fromtimestamp(time.time()+row["interval"], timezone.utc).isoformat()
    c = db()
    c.execute("""UPDATE tasks SET success=success+?, failed=failed+?, last_request=?,
                 next_request=?, status=?, last_code=?, last_error=? WHERE id=?""",
              (int(ok), int(not ok), now, next_t, "Running" if ok or err else "Error",
               code, err, task_id))
    c.commit(); c.close()
    log_request(task_id, code, ok, ms, err)

def schedule_task(task_id):
    c=db(); row=c.execute("SELECT * FROM tasks WHERE id=?",(task_id,)).fetchone(); c.close()
    if not row or not row["running"]: return
    scheduler.add_job(ping_task, "interval", seconds=row["interval"], args=[task_id],
                      id=task_id, replace_existing=True, max_instances=1,
                      coalesce=True, misfire_grace_time=row["interval"])
    ping_task(task_id)

@app.route("/")
def index(): return render_template("index.html")

@app.get("/api/tasks")
def tasks():
    c=db(); rows=c.execute("SELECT * FROM tasks ORDER BY created_at").fetchall(); c.close()
    return jsonify([dict(r) for r in rows])

@app.post("/api/tasks")
def create():
    data=request.get_json(silent=True) or {}
    url=str(data.get("url","")).strip()
    try: interval=int(data.get("interval",7))
    except: interval=7
    if interval < 5: return jsonify(error="Minimum interval is 5 seconds."), 400
    if len(url)>2048: return jsonify(error="URL is too long."), 400
    ok,msg=valid_public_url(url)
    if not ok: return jsonify(error=msg), 400
    c=db(); count=c.execute("SELECT COUNT(*) n FROM tasks").fetchone()["n"]
    if count>=MAX_TASKS: c.close(); return jsonify(error=f"Maximum {MAX_TASKS} tasks allowed."), 429
    tid=str(uuid.uuid4()); now=datetime.now(timezone.utc).isoformat()
    c.execute("INSERT INTO tasks(id,url,interval,created_at) VALUES(?,?,?,?)",(tid,url,interval,now))
    c.commit(); c.close()
    return jsonify(id=tid), 201

@app.post("/api/tasks/<tid>/start")
def start(tid):
    c=db(); row=c.execute("SELECT * FROM tasks WHERE id=?",(tid,)).fetchone()
    if not row: c.close(); return jsonify(error="Task not found"),404
    ok,msg=valid_public_url(row["url"])
    if not ok: c.close(); return jsonify(error=msg),400
    started=datetime.now(timezone.utc).isoformat()
    c.execute("UPDATE tasks SET running=1,status='Running',started_at=?,last_error=NULL WHERE id=?",(started,tid))
    c.commit(); c.close()
    schedule_task(tid); return jsonify(ok=True)

@app.post("/api/tasks/<tid>/stop")
def stop(tid):
    try: scheduler.remove_job(tid)
    except: pass
    c=db(); c.execute("UPDATE tasks SET running=0,status='Stopped',next_request=NULL WHERE id=?",(tid,)); c.commit(); c.close()
    return jsonify(ok=True)

@app.delete("/api/tasks/<tid>")
def delete(tid):
    try: scheduler.remove_job(tid)
    except: pass
    c=db(); c.execute("DELETE FROM logs WHERE task_id=?",(tid,)); c.execute("DELETE FROM tasks WHERE id=?",(tid,)); c.commit(); c.close()
    return jsonify(ok=True)

@app.get("/api/tasks/<tid>/logs")
def logs(tid):
    c=db(); rows=c.execute("SELECT * FROM logs WHERE task_id=? ORDER BY id DESC LIMIT 100",(tid,)).fetchall(); c.close()
    return jsonify([dict(r) for r in rows])

def boot():
    init_db(); scheduler.start()
    c=db(); ids=[r["id"] for r in c.execute("SELECT id FROM tasks WHERE running=1").fetchall()]; c.close()
    for tid in ids: schedule_task(tid)

if __name__=="__main__":
    boot()
    app.run(host="0.0.0.0", port=PORT, threaded=True)

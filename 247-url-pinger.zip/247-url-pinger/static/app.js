const $=s=>document.querySelector(s), tasksEl=$("#tasks"), tpl=$("#card"); let tasks={};
function esc(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
async function api(u,o={}){let r=await fetch(u,{headers:{"Content-Type":"application/json"},...o}),d=await r.json();if(!r.ok)throw Error(d.error||"Request failed");return d}
function render(t){let old=document.getElementById("t-"+t.id), el=old||tpl.content.firstElementChild.cloneNode(true);el.id="t-"+t.id;el.querySelector(".url").value=t.url;el.querySelector(".interval").value=t.interval;el.querySelector(".state").textContent=t.status;
el.querySelector(".status").className="status "+t.status.toLowerCase();el.querySelector(".success").textContent=t.success;el.querySelector(".failed").textContent=t.failed;el.querySelector(".last").textContent=t.last_request?new Date(t.last_request).toLocaleTimeString():"—";el.querySelector(".next").textContent=t.running&&t.next_request?Math.max(0,Math.ceil((new Date(t.next_request)-Date.now())/1000))+"s":"—";el.querySelector(".start").textContent=t.running?"Stop":"Start";
el.querySelector(".start").onclick=()=>api(`/api/tasks/${t.id}/${t.running?"stop":"start"}`,{method:"POST"}).then(load).catch(alert);
el.querySelector(".delete").onclick=()=>confirm("Delete this task?")&&api(`/api/tasks/${t.id}`,{method:"DELETE"}).then(load);
el.querySelector(".interval").onchange=e=>{alert("Interval changes apply after recreating this task.");e.target.value=t.interval};
if(!old)tasksEl.appendChild(el); loadLogs(t.id)}
async function loadLogs(id){try{let ls=await api(`/api/tasks/${id}/logs`), box=$("#t-"+id+" .logrows");box.innerHTML=ls.map(x=>`<div class="log"><span>${new Date(x.timestamp).toLocaleString()}</span><span>${x.code||"—"}</span><span class="${x.success?"ok":"bad"}">${x.success?"Success":esc(x.error||"Failed")}</span><span>${x.response_ms}ms</span></div>`).join("")}catch{}}
async function load(){let a=await api("/api/tasks");tasksEl.innerHTML="";a.forEach(t=>{tasks[t.id]=t;render(t)});$("#count").textContent=a.length+" task"+(a.length===1?"":"s");}
$("#add").onclick=async()=>{let url=prompt("Enter a public HTTP/HTTPS URL:");if(!url)return;let interval=prompt("Interval in seconds (minimum 5):","7");if(!interval)return;try{await api("/api/tasks",{method:"POST",body:JSON.stringify({url,interval:Number(interval)})});load()}catch(e){alert(e.message)}};
$("#theme").onclick=()=>{document.body.classList.toggle("dark");localStorage.dark=document.body.classList.contains("dark")?"1":""};if(localStorage.dark)document.body.classList.add("dark");
load();setInterval(load,2000);

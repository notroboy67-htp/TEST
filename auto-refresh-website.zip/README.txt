AUTO REFRESH WEBSITE

1. Extract the ZIP.
2. Open index.html in a browser.
3. Enter the website URL.
4. Enter the refresh interval in seconds (default: 17).
5. Press Start.

IMPORTANT:
Some websites block being displayed inside an iframe using security headers
such as X-Frame-Options or Content-Security-Policy. If that happens, the
embedded preview cannot display that site. A server-side/proxy version would
be needed for those sites.

#!/bin/bash
set -e
cd "$(dirname "$0")"
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is not installed."
  echo "Install it with: pkg install python   (Termux)"
  echo "or: sudo apt update && sudo apt install -y python3 python3-venv"
  exit 1
fi

if [ ! -d .venv ]; then
  python3 -m venv .venv 2>/dev/null || {
    echo "venv creation failed."
    echo "Ubuntu/Debian: sudo apt install -y python3-venv"
    echo "Termux: pkg install python"
    exit 1
  }
fi
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
echo
echo "NRB Auto Bot is running at:"
echo "  http://127.0.0.1:5000"
echo "  http://YOUR-SERVER-IP:5000"
echo
python app.py

import json, os, shlex, subprocess, threading, time, uuid
from flask import Flask, jsonify, render_template, request

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "bots.json")
app = Flask(__name__)

lock = threading.Lock()
workers = {}
logs = {}

def load_bots():
    if not os.path.exists(DATA):
        return []
    try:
        with open(DATA, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []

def save_bots(bots):
    tmp = DATA + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(bots, f, indent=2)
    os.replace(tmp, DATA)

def add_log(bot_id, text):
    with lock:
        logs.setdefault(bot_id, [])
        logs[bot_id].append(text.rstrip())
        logs[bot_id] = logs[bot_id][-120:]

def run_commands(bot):
    bot_id = bot["id"]
    interval = max(1, int(bot.get("interval", 10)))
    commands = bot.get("commands", "")
    while bot_id in workers and not workers[bot_id]["stop"].is_set():
        started = time.strftime("%Y-%m-%d %H:%M:%S")
        add_log(bot_id, f"[{started}] Running commands...")
        for line in commands.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            add_log(bot_id, f"$ {line}")
            try:
                # shell=True allows normal shell syntax, pipes, &&, etc.
                p = subprocess.run(
                    line, shell=True, cwd=BASE,
                    capture_output=True, text=True, timeout=60
                )
                if p.stdout.strip():
                    add_log(bot_id, p.stdout)
                if p.stderr.strip():
                    add_log(bot_id, p.stderr)
                add_log(bot_id, f"[exit {p.returncode}]")
            except subprocess.TimeoutExpired:
                add_log(bot_id, "[timeout] Command exceeded 60 seconds.")
            except Exception as e:
                add_log(bot_id, f"[error] {e}")
        workers[bot_id]["stop"].wait(interval)

def start_bot(bot):
    bot_id = bot["id"]
    if bot_id in workers:
        return
    stop = threading.Event()
    workers[bot_id] = {"stop": stop}
    logs.setdefault(bot_id, [])
    t = threading.Thread(target=run_commands, args=(bot,), daemon=True)
    workers[bot_id]["thread"] = t
    t.start()

def stop_bot(bot_id):
    item = workers.pop(bot_id, None)
    if item:
        item["stop"].set()

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/bots", methods=["GET"])
def get_bots():
    bots = load_bots()
    for b in bots:
        b["running"] = b["id"] in workers
    return jsonify(bots)

@app.route("/api/bots", methods=["POST"])
def create_bot():
    data = request.get_json(force=True)
    bot = {
        "id": uuid.uuid4().hex[:8],
        "name": str(data.get("name") or "New Bot")[:80],
        "url": str(data.get("url") or "")[:500],
        "interval": max(1, int(data.get("interval", 10))),
        "commands": str(data.get("commands") or "")[:10000]
    }
    bots = load_bots()
    bots.append(bot)
    save_bots(bots)
    return jsonify(bot), 201

@app.route("/api/bots/<bot_id>", methods=["PUT"])
def update_bot(bot_id):
    data = request.get_json(force=True)
    bots = load_bots()
    old = next((b for b in bots if b["id"] == bot_id), None)
    if not old:
        return jsonify({"error": "Bot not found"}), 404
    was_running = bot_id in workers
    if was_running:
        stop_bot(bot_id)
    old["name"] = str(data.get("name") or old["name"])[:80]
    old["url"] = str(data.get("url") or "")[:500]
    old["interval"] = max(1, int(data.get("interval", old["interval"])))
    old["commands"] = str(data.get("commands") or "")[:10000]
    save_bots(bots)
    if was_running:
        start_bot(old)
    old["running"] = bot_id in workers
    return jsonify(old)

@app.route("/api/bots/<bot_id>", methods=["DELETE"])
def delete_bot(bot_id):
    stop_bot(bot_id)
    bots = [b for b in load_bots() if b["id"] != bot_id]
    save_bots(bots)
    logs.pop(bot_id, None)
    return jsonify({"ok": True})

@app.route("/api/bots/<bot_id>/start", methods=["POST"])
def start(bot_id):
    bot = next((b for b in load_bots() if b["id"] == bot_id), None)
    if not bot:
        return jsonify({"error": "Bot not found"}), 404
    start_bot(bot)
    return jsonify({"running": True})

@app.route("/api/bots/<bot_id>/stop", methods=["POST"])
def stop(bot_id):
    stop_bot(bot_id)
    return jsonify({"running": False})

@app.route("/api/bots/<bot_id>/logs", methods=["GET"])
def get_logs(bot_id):
    return jsonify(logs.get(bot_id, [])[-120:])

if __name__ == "__main__":
    for b in load_bots():
        # Do not auto-run saved bots; user starts them from the dashboard.
        pass
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)

# NRB Auto Bot

A simple web dashboard for multiple repeating bots/tasks.

## Features
- Add unlimited bots with the `+ Add Bot` button.
- Edit and delete bots.
- Start/stop each bot.
- Default interval: 10 seconds.
- Run terminal commands repeatedly.
- Live command output.
- Optional URL field for each bot.
- Data is saved in `bots.json`.

## Important
This program executes the commands you enter on the machine where `app.py` is running.
Only run commands you trust. Do not expose this dashboard to the public internet without authentication/firewall protection.

## Termux

```bash
pkg update
pkg install python
unzip nrb_auto_bot.zip
cd nrb_auto_bot
chmod +x start.sh
./start.sh
```

Open:

```text
http://127.0.0.1:5000
```

For access from another device on the same network, find the Termux IP and use:

```text
http://PHONE-IP:5000
```

## Ubuntu/Debian

```bash
sudo apt update
sudo apt install -y python3 python3-venv unzip
unzip nrb_auto_bot.zip
cd nrb_auto_bot
chmod +x start.sh
./start.sh
```

## Example bot

Name: `My 10s Bot`

Interval: `10`

Commands:

```text
apt update
ls
```

For `apt update`, Ubuntu may require root privileges. If the process is not running as root, use commands appropriate for your account.

## Notes
- Commands run sequentially every interval.
- Each individual command has a 60-second timeout.
- The dashboard itself does not automatically start saved bots after a server restart; click Start when you want to run one.

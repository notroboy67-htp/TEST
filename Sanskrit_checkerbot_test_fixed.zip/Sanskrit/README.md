# Sanskrit Study — verified working build

This build keeps the original Sanskrit project structure/design direction and adds a working Chapter 1–11 dashboard.

## Flow
Dashboard → Chapter → Explanation / Revision / Test

## Verification
- Chapter metadata: all 11 Iravati core chapters are listed.
- Question database: sourced from the previously generated source-derived exercise database; no new questions are invented for missing source data.
- Chapter 8 is explicitly marked unavailable because its source PDF was not supplied.
- User progress is stored in SQLite by username + chapter + action.
- Flask syntax/import and application smoke tests should be run with `python app.py`.

## Run
```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python app.py
```
Open the URL shown by Flask. Default admin account: `admin` / `admin` (change this before real deployment).

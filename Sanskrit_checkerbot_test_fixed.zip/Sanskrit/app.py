from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3, json, os
from pathlib import Path

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'change-this-secret-in-production')
BASE_DIR = Path(__file__).resolve().parent
DB = BASE_DIR / 'site.db'
with open(BASE_DIR / 'static' / 'chapters.json', encoding='utf-8') as f:
    CHAPTERS = json.load(f)

CHAPTER_META = {
1: ('अहं नमामि', 1, 'गुरु, प्रभु, मातृभूमि, सदाचार और सत्कर्म के प्रति श्रद्धा।'),
2: ('मातामह्याः उपनेत्रम्', 6, 'मातामही के उपनेत्र के खो जाने और उसके खोजे जाने की सरल कथा।'),
3: ('नद्यः', 15, 'नदियों के महत्व, उपयोग और प्रकृति से उनके संबंध पर आधारित पाठ।'),
4: ('नीतिवचनानि', 22, 'नीतिपरक वचनों के माध्यम से सदाचार और जीवन-मूल्यों की शिक्षा।'),
5: ('दानवीरः कर्णः', 33, 'कर्ण के दानशील स्वभाव और त्याग की प्रसिद्ध कथा।'),
6: ('न गङ्गदत्तः पुनरेति कूपम्', 41, 'गङ्गदत्त की कथा के माध्यम से निर्णय, परिणाम और सावधानी का संदेश।'),
7: ('विद्यामहिमा', 49, 'विद्या के महत्व, विनय, पात्रता और उसके अमूल्य स्वरूप की प्रशंसा।'),
8: ('बिलस्य वाणी न कदापि मे श्रुता', 59, 'इस अध्याय का स्रोत-पृष्ठ उपयोगकर्ता द्वारा अभी उपलब्ध नहीं कराया गया है।'),
9: ('ऋतुः वसन्तः', 67, 'वसन्त ऋतु की प्राकृतिक शोभा और उससे जुड़े वातावरण का वर्णन।'),
10: ('सहजः स्वास्थ्यलाभः', 75, 'स्वास्थ्य और सहज जीवन-शैली से जुड़े पाठ का अध्ययन।'),
11: ('आर्यभटः', 85, 'आर्यभट के वैज्ञानिक विचार, पृथ्वी की गति और ग्रहण से संबंधित सिद्धान्त।')
}

def db(): return sqlite3.connect(DB)

def init_db():
    with db() as con:
        con.execute('CREATE TABLE IF NOT EXISTS users (username TEXT PRIMARY KEY, password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT "student")')
        con.execute('CREATE TABLE IF NOT EXISTS progress (username TEXT NOT NULL, chapter INTEGER NOT NULL, action TEXT NOT NULL, score INTEGER DEFAULT 0, total INTEGER DEFAULT 0, updated_at TEXT DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(username, chapter, action))')
        con.execute('CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, event_type TEXT, details TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)')
        if not con.execute('SELECT 1 FROM users WHERE username="admin"').fetchone():
            con.execute('INSERT INTO users VALUES (?,?,?)', ('admin', generate_password_hash('admin'), 'admin'))
        con.execute('UPDATE users SET role="admin" WHERE username="admin"')

def login_required(): return bool(session.get('username'))

def save_event(event_type, details=''):
    if session.get('username'):
        with db() as con: con.execute('INSERT INTO events(username,event_type,details) VALUES(?,?,?)',(session['username'],event_type,str(details)[:500]))

@app.route('/')
def home(): return redirect(url_for('dashboard' if login_required() else 'login'))

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        u=request.form.get('username','').strip(); p=request.form.get('password','')
        with db() as con: row=con.execute('SELECT username,password_hash,role FROM users WHERE username=?',(u,)).fetchone()
        if row and check_password_hash(row[1],p):
            session.clear(); session.update(username=row[0],role=row[2]); save_event('login','success'); return redirect(url_for('dashboard'))
        flash('Invalid username or password.')
    return render_template('login.html')

@app.route('/register', methods=['GET','POST'])
def register():
    if request.method=='POST':
        u=request.form.get('username','').strip(); p=request.form.get('password','')
        if not u or len(p)<8: flash('Username is required and password must be at least 8 characters.')
        else:
            try:
                with db() as con: con.execute('INSERT INTO users(username,password_hash,role) VALUES(?,?,?)',(u,generate_password_hash(p),'student'))
                flash('Account created successfully. Please log in.'); return redirect(url_for('login'))
            except sqlite3.IntegrityError: flash('Username already exists.')
    return render_template('register.html')

@app.route('/dashboard')
def dashboard():
    if not login_required(): return redirect(url_for('login'))
    return render_template('dashboard.html', username=session['username'], chapters=CHAPTER_META)

@app.route('/api/chapters')
def api_chapters():
    if not login_required(): return jsonify(ok=False),401
    out=[]
    for n,(title,page,focus) in CHAPTER_META.items():
        c=CHAPTERS.get(str(n),{})
        out.append({'chapter':n,'title':title,'page':page,'focus':focus,'source':c.get('source'),'sourceAvailable':c.get('sourceAvailable',False),'exercises':c.get('exercises',[])})
    return jsonify(out)

@app.route('/api/progress', methods=['GET','POST'])
def api_progress():
    if not login_required(): return jsonify(ok=False),401
    if request.method=='POST':
        d=request.get_json(silent=True) or {}; n=int(d.get('chapter',0)); a=str(d.get('action',''))
        if n not in CHAPTER_META or a not in {'explanation','revision','test'}: return jsonify(ok=False,error='invalid data'),400
        with db() as con: con.execute('INSERT INTO progress(username,chapter,action,score,total) VALUES(?,?,?,?,?) ON CONFLICT(username,chapter,action) DO UPDATE SET score=excluded.score,total=excluded.total,updated_at=CURRENT_TIMESTAMP',(session['username'],n,a,int(d.get('score',0)),int(d.get('total',0))))
        return jsonify(ok=True)
    with db() as con: rows=con.execute('SELECT chapter,action,score,total,updated_at FROM progress WHERE username=?',(session['username'],)).fetchall()
    return jsonify([dict(chapter=r[0],action=r[1],score=r[2],total=r[3],updated_at=r[4]) for r in rows])

@app.route('/api/cheat-event', methods=['POST'])
def cheat_event():
    if not login_required(): return jsonify(ok=False),401
    d=request.get_json(silent=True) or {}; save_event(d.get('event_type','activity'),d.get('details','')); return jsonify(ok=True)

@app.route('/admin')
def admin():
    if not login_required() or session.get('role')!='admin': flash('Admin access only.'); return redirect(url_for('dashboard'))
    with db() as con: events=con.execute('SELECT id,username,event_type,details,created_at FROM events ORDER BY id DESC LIMIT 500').fetchall()
    return render_template('admin.html',username=session['username'],events=events,stats=(len(events),len(set(e[1] for e in events))) )

@app.route('/logout')
def logout(): save_event('logout',''); session.clear(); return redirect(url_for('login'))

if __name__=='__main__':
    init_db(); app.run(host='0.0.0.0',port=int(os.environ.get('PORT','8080')),debug=False)

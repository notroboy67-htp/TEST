CheckerBot
==========

File: static/checkerbot.js

Purpose:
- Checks student answers against the answers stored in chapters.json.
- Normalizes Sanskrit punctuation/spacing before comparison.
- Supports one answer or multiple accepted answers.
- Provides similar practice questions from the same chapter without inventing new textbook answers.
- Can create a randomized test from the available chapter question data.

Usage in a page:
  <script src="/static/checkerbot.js"></script>
  await CheckerBot.load('/static/chapters.json');
  const questions = CheckerBot.createTest(1, 10);
  const result = CheckerBot.check(questions[0], '...');

The dashboard already loads CheckerBot and uses it for answer checking.
